/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#define DEPTH 7                        //1 to check the minimax tree
#define NEGLARGE -1000
#define POSLARGE 1000
using namespace std;
using namespace Desdemona;
int iscontinue(int max,int alpha,int beta)
{
        if(alpha>=beta)
            return 0;
        else
            return 1;

}

signed int minimax(const OthelloBoard& board,Turn turn,int d,list<Move> moves1,int alpha,int beta,int max)  // d for depth of the Minimax algo
{
    signed int black=board.getBlackCount();
    //black=black*black;

    signed int red=board.getRedCount();
    //red=red*red;
    //printf("Black is %d Red is %d\n",black,red);
    if(d==DEPTH)
    {
        if(turn==RED)
        {    //printf("Black %d Red %d\n",board.getBlackCount(),board.getRedCount());
            return (black-red);
        }
        else
        {
            return (red-black);
        }
    }
    int num_nodes;
    Turn oppturn;
    if(turn == RED)
        oppturn = BLACK;
    else
        oppturn = RED;

    num_nodes=moves1.size();

    OthelloBoard* oth1 = new OthelloBoard [num_nodes];
    signed int* values = new signed int[num_nodes];

    list<Move>::iterator it = moves1.begin();

    for(int i=0;i<num_nodes&&(iscontinue(max,alpha,beta)==1);i++,it++)
    {
        oth1[i]=board;
        oth1[i].makeMove(turn,*it);
        list<Move> moves2 = oth1[i].getValidMoves(oppturn);
        if(moves2.empty()==true)
        {
            //cout<<"First Case"<<endl;
            moves2 = oth1[i].getValidMoves(turn);
            values[i]=minimax(oth1[i],turn,d,moves2,alpha,beta,max);//get back  to it later
        }

        else if(d!=0)
        {
            //cout<<"Second Case"<<endl;
            values[i]=minimax(oth1[i],oppturn,d+1,moves2,alpha,beta,-1*max);
            if(max==1)
            {
                if(values[i]>alpha)
                    alpha=values[i];
            }
            else if(max==-1)
            {
                if(values[i]<beta)
                    beta=values[i];
            }
        }
        else if(d==0)
    {
        //cout<<"Number of nodes: "<<num_nodes<<endl<<"Depth: "<<d<<endl<<endl;
        int pos=0;        
        for(int j=0;j<num_nodes;j++)
        {
            values[j]=minimax(oth1[i],oppturn,d+1,moves2,alpha,beta,-1*max);
            if(values[j]>alpha)
            {
                pos=j;
                break;
            }
        }
        //cout<<endl;
        delete [] values;
        delete [] oth1;
        return pos;
    }
    }

    if((d%2)==0)
    {
        delete [] values;
        delete [] oth1;
        return alpha;
    }
    if((d%2)!=0)
    {
        delete [] values;
        delete [] oth1;
        return beta;
    }
    return 0;
}

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play(const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play(const OthelloBoard& board )
{
    //cout<<"Displaying gen";
    //gen.print();
    //cout<<"Black is "<<board.getBlackCount()<<"Red is "<<board.getRedCount()<<endl;

    list<Move> moves = board.getValidMoves( turn );
    if(moves.size()==0)
        return Move::pass();
    signed int num=minimax(board,turn,0,moves,NEGLARGE,POSLARGE,1);
    list<Move>::iterator it = moves.begin();

    //cout<<" Possible num_moves are "<<moves.size()<<" "<<"Move played is "<<++num<<endl;

    for(int i=0; i < num; it++, i++);    
    return *it;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot ( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


