/**
* @file SlowBot.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Bot that randomly chooses a move to play with you
*/

#include "NumberGame.h"
#include "NumberGamePlayer.h"
#include <cstdlib>
#include <ctime>
using namespace std;
using namespace Potato;

class SlowBot: public NumberGamePlayer
{
    public:
        /**
         * Initialisation routines here
         */
        SlowBot();
        virtual ~SlowBot() {}

        /**
         * Play something 
         */
        virtual Move play( const Move prevOppMove );
    private:
};


SlowBot::SlowBot()
{
    time_t t;
    time( &t );
    srand( t );
}

Move SlowBot::play( const Move prevOppMove )
{
    int range = (NumberGame::Max - NumberGame::Min);
    int randNo = rand() % (range) + NumberGame::Min;
    int tmp;

    for( int i = 0; i < 1000000; i++ )
        for( int j = 0; j < 1000; j++ )
            tmp = i + j;

    return randNo;
}

// The following lines are _very_ important to create a bot module for Potato

extern "C" {
    NumberGamePlayer* createBot( )
    {
        return new SlowBot( );
    }

    void destroyBot( NumberGamePlayer* bot )
    {
        delete bot;
    }
}


