/**
* @file RandomBot.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Bot that randomly chooses a move to play with you
*/

#include "NumberGame.h"
#include "NumberGamePlayer.h"
#include <cstdlib>
#include <ctime>
using namespace std;
using namespace Potato;

class RandomBot: public NumberGamePlayer
{
    public:
        /**
         * Initialisation routines here
         */
        RandomBot();
        virtual ~RandomBot() {}

        /**
         * Play something 
         */
        virtual Move play( const Move prevOppMove );
    private:
};

RandomBot::RandomBot() :
    NumberGamePlayer( )
{
    time_t t;
    time( &t );
    srand( t );
}

Move RandomBot::play( const Move prevOppMove )
{
    int range = (NumberGame::Max - NumberGame::Min);
    int randNo = rand() % (range) + NumberGame::Min;
    
    return randNo;
}

// The following lines are _very_ important to create a bot module for Potato

extern "C" {
    NumberGamePlayer* createBot( )
    {
        return new RandomBot( );
    }

    void destroyBot( NumberGamePlayer* bot )
    {
        delete bot;
    }
}


