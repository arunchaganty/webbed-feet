/**
 * @file TuringBot.cpp
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-01
 * If you were a computer program, a human player acted just like a bot, isn't
 * he/she a bot?
 */

#include <iostream>
using namespace std;

#include "NumberGame.h"
#include "NumberGamePlayer.h"
using namespace Potato;

/**
 * @brief TuringBot Human player
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-01
 * If you were a computer program, a human player acted just like a bot, isn't
 * he/she a bot?
 */
class TuringBot: public NumberGamePlayer
{
    public:

        /**
         * Default constructor
         */
        TuringBot();
        virtual ~TuringBot() {}
        Move play( const Move prevOppMove );

    private:

};

TuringBot::TuringBot():
    NumberGamePlayer()
{
}

Move TuringBot::play( const Move prevOppMove )
{
    int move;
    cin >> move;
    return move;
}

// The following lines are _very_ important to create a bot module for Potato

extern "C" {
    NumberGamePlayer* createBot( )
    {
        return new TuringBot( );
    }

    void destroyBot( NumberGamePlayer* bot )
    {
        delete bot;
    }
}


