/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "NumberGame.h"
#include "NumberGamePlayer.h"
#include <cstdlib>
using namespace std;
using namespace Potato;

class MyBot: public NumberGamePlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot();

        /**
         * Play something 
         */
        virtual Move play( const Move prevOppMove );
    private:
};

MyBot::MyBot( )
    : NumberGamePlayer( )
{
}

Move MyBot::play( const Move prevOppMove )
{
    int range = (NumberGame::Max - NumberGame::Min);
    int randNo = rand() % (range) + NumberGame::Min;

    return randNo;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    NumberGamePlayer* createBot( )
    {
        return new MyBot( );
    }

    void destroyBot( NumberGamePlayer* bot )
    {
        delete bot;
    }
}


