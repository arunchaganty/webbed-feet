/**
 * @file NumberGamePlayer.cpp
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-01
 * Class for the Othello board 
 */

#include "NumberGamePlayer.h"
using namespace Potato;

NumberGamePlayer::NumberGamePlayer( ) 
{
}

Move NumberGamePlayer::play( const Move oppPrevMove )
{
    return 0;
}

