/**
* @file botLoader.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-01-27
* Contains functions to handle loading of bots
*/

#include <iostream>
#include <sys/stat.h>
#include <unistd.h>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <dlfcn.h>
using namespace std;

#include "botLoader.h"
using namespace Potato;

typedef NumberGamePlayer* ( *CreateBotFn ) ();

void loadInit()
{
    cerr << "Loading libNumberGame..." << endl;
    if( (dlopen( "lib/libNumberGame.so", RTLD_NOW) == NULL ) )
    {
        char* error = dlerror();
        cerr << error << endl;
        throw exception();
    }
}

NumberGamePlayer* loadBot( string botPath )
{
    void* botMod;
    NumberGamePlayer* bot;
    CreateBotFn createBotFn;

    // TODO: Security checks

    cerr << "Loading bot..." << endl;
    botMod = dlopen( botPath.c_str(), RTLD_NOW );
    if( botMod == NULL )
    {
        char* error = dlerror();
        cerr << error << endl;
        // "Could not load bot";
        throw exception();
        //throw InvalidBotModule( "Could not load bot" );
    }

    createBotFn = (CreateBotFn) dlsym( botMod, "createBot" );
    if( createBotFn == NULL )
    {
        char* error = dlerror();
        cerr << error << endl;
        throw exception();
    }

    bot = createBotFn();

    return bot;
}

