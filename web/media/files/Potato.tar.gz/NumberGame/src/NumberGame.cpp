/**
 * @file NumberGame.cpp
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-01
 * Basic primitives
 */

#include <iostream>
#include <fstream>
#include <cerrno>
#include <cassert>

#include <time.h>
#include <signal.h>
#include <sys/types.h>
using namespace std;

#include "NumberGame.h"
using namespace Potato;

// TODO: Make this defined in a config file somewhere
#define BOT_TIMEOUT 2

#define DEFAULT_DURATION 20

enum ExceptionFlags
{
    EFLAGS_NONE,
    EFLAGS_TIMEOUT=0x1,
    EFLAGS_UNHANDLED=0x2
};
static Move launchEnvironment( NumberGamePlayer& player, const Move prevMove );
static void handleErrors( bool dq1, bool dq2, bool to1, bool to2, bool cr1, bool cr2 );
extern struct Options g_Options;

NumberGame::NumberGame( NumberGamePlayer& player1, NumberGamePlayer& player2, int duration )
    : player1(player1), player2(player2), duration(duration), plays( 0 ), player1Score( 0 ), player2Score( 0 )
{
}

NumberGame::NumberGame( NumberGamePlayer& player1, NumberGamePlayer& player2 )
    : player1(player1), player2(player2), duration(DEFAULT_DURATION), plays( 0 ), player1Score( 0 ), player2Score( 0 )
{
}

bool NumberGame::validateMove( const Move move )
{
    if( move >= Min && move <= Max )
    {
        return true;
    }
    else
    {
        return false;
    }
}

void NumberGame::makeMove( const Move move1, const Move move2 )
{
    assert( validateMove( move1 ) && validateMove( move2 ) );

    if( move1 == ( move2 - 1 ) )
    {
        player1Score += move1 + move2;
    }
    else if( move2 == ( move1 - 1 ) )
    {
        player2Score += move1 + move2;
    }
    else
    {
        player1Score += move1;
        player2Score += move2;
    }
}

void NumberGame::printState()
{
    if( g_Options.isVerbose )
    {
        cerr << player1Score << " " << player2Score << endl;
    }
    if( g_Options.shouldStep )
    {
        cin.ignore();
    }
}

void NumberGame::printState( Move move1, Move move2 )
{
    if( g_Options.isVerbose )
    {
        cerr << move1 << " " << move2 << " >> ";
        cerr << player1Score << " " << player2Score << endl;
    }
    if( g_Options.shouldStep )
    {
        cin.ignore();
    }
}

int NumberGame::startGame()
{
    // Condition codes
    bool cr1, cr2;
    bool to1, to2;
    bool dq1, dq2;
    cr1 = cr2 = to1 = to2 = dq1 = dq2 = false;

    Move player1Move = 0;
    Move player2Move = 0;
    printState();

    do
    {
        Move move1 = 0;
        Move move2 = 0;

        // Spawn a thread to set up an execution environment for the player.
        try
        {
            move1 = launchEnvironment( player1, player2Move );
        }
        catch( InvalidMoveException& e )
        {
            dq1 = true;
        }
        catch( TimeoutException& e )
        {
            to1 = true;
        }
        catch( BotException& e )
        {
            cr1 = true;
        }

        try
        {
            move2 = launchEnvironment( player2, player1Move );
        }
        catch( InvalidMoveException& e )
        {
            dq2 = true;
        }
        catch( TimeoutException& e )
        {
            to2 = true;
        }
        catch( BotException& e )
        {
            cr2 = true;
        }
        handleErrors( dq1, dq2, to1, to2, cr1, cr2 );

        makeMove( move1, move2 );

        // Do any actions
        postPlayActions( move1, move2 );

        printState(move1, move2);

        // Increment plays
        plays++;
    } while( !isGameOver() );

    cerr << "Game Over" << endl;

    return player1Score - player2Score;
}

int NumberGame::replayGame( string filename )
{
    throw exception();
}

bool NumberGame::isGameOver()
{
    // The game is over when there are no valid moves remaining
    return ( player1Score >= 100 ) || ( player2Score >= 100 ); 
}

void NumberGame::postPlayActions( Move& move1, Move& move2 )
{

}

/* Static functions */

/**
 * \struct BotEnvironment
 * Store arguments to be passed to thread
 */
struct BotEnvironment
{
    NumberGamePlayer& player;
    const Move& oppPrevMove;
    Move& move;
    ExceptionFlags flags;

    BotEnvironment( NumberGamePlayer& player, const Move& oppPrevMove, Move& move ) :
        player( player ), oppPrevMove( oppPrevMove ), move( move ) {}
};

struct TimeoutClosure
{
    pthread_t tid;
    BotEnvironment& environ;

    TimeoutClosure( pthread_t tid, BotEnvironment& environ):
        tid( tid ), environ( environ ) {}
};

typedef void* (*start_routine) (void *);
static void createEnvironment( BotEnvironment& environ );


/**
* Is a thread cancel function to delete an installed timer
*/
static void timerCleanup( void* arg )
{
    timer_t timerid = (timer_t) arg;
    timer_delete( timerid );
}

/**
* Is a thread cancel function to reset the stdout
*/
static void stdCleanup( void* arg )
{
    FILE* stdout_ = (FILE*) arg;
    *stdout = *stdout_;
}



/**
* Is called when the player's thread times out
*/
static void handleTimeout( sigval_t val )
{
    TimeoutClosure *closure = (TimeoutClosure*) val.sival_ptr;
    pthread_cancel( closure->tid );

    closure->environ.flags = EFLAGS_TIMEOUT;

    delete closure;
}

/**
 * Setup environ for player to play.
 * Runs in new thread context
 */
static void createEnvironment( BotEnvironment& environ )
{
    // Setup timers, etc.
    timer_t timerid;
    struct itimerspec its;
    struct sigevent evt;

    // Setup thread to allow it to be cancelled
    pthread_setcancelstate( PTHREAD_CANCEL_ENABLE, NULL );
    pthread_setcanceltype( PTHREAD_CANCEL_ASYNCHRONOUS, NULL );

    // Create a timer
    evt.sigev_notify = SIGEV_THREAD;
    evt.sigev_signo = 0;
    evt.sigev_value.sival_ptr = new TimeoutClosure( pthread_self(), environ );
    evt.sigev_notify_function = handleTimeout;
    evt.sigev_notify_attributes = NULL;

    // Using _POSIX_THREAD_CPUTIME is fairer to the bot because it counts only
    // the time it's thread (i.e. it) gets.
    timer_create( _POSIX_THREAD_CPUTIME, &evt, &timerid );

    // Push a handler that will delete the timer
    pthread_cleanup_push( timerCleanup, timerid );

    // Setup the timer for X seconds.
    its.it_value.tv_sec = BOT_TIMEOUT;
    its.it_value.tv_nsec = 0;
    its.it_interval.tv_sec = 0;
    its.it_interval.tv_nsec = 0;

    if( !g_Options.ignoreTime )
    {
        timer_settime( timerid, 0, &its, NULL );
    }

    // Redirect stdout
    FILE stdout_ = *stdout; 
    *stdout = *stderr;

    // Push a handler that will reset the stdout
    pthread_cleanup_push( stdCleanup, &stdout_ );

    // Finally let the bot play
    try {
        environ.move = environ.player.play( environ.oppPrevMove );
    }
    catch(exception& e)
    {
        environ.flags = EFLAGS_UNHANDLED;
    }

    // Remove aforementioned handler
    pthread_cleanup_pop( true );
    pthread_cleanup_pop( true );
}

/**
 * Setup a thread, and call player.play
 * @param player - Player to play
 */
static Move launchEnvironment( NumberGamePlayer& player, const Move oppPrevMove )
{
    int s;
    pthread_t t_id;
    pthread_attr_t attr;
    Move move = 0;
    BotEnvironment environ( player, oppPrevMove, move );

    // Launch a thread
    pthread_attr_init( &attr );
    s = pthread_create( &t_id, &attr, (start_routine) createEnvironment, &environ ) != 0;
    if( s != 0 )
    {
        errno = s;
        perror( "pthread_create" );
    }

    pthread_join( t_id, NULL );

    // Check environ flags for exceptions
    switch( environ.flags )
    {
        case EFLAGS_TIMEOUT:
            throw TimeoutException(NONE);
            break;
        case EFLAGS_UNHANDLED:
            throw BotException(NONE);
            break;
        case EFLAGS_NONE:
        default:;
    }

    return move;
}

static void handleErrors( bool dq1, bool dq2, bool to1, bool to2, bool cr1, bool cr2 )
{
    if( dq1 || dq2 )
    {
        if( dq1 && dq2 )
        {
            throw BotInvalidMoveException( BOTH );
        }
        else if( dq1 )
        {
            throw BotInvalidMoveException( PL1 );
        }
        else
        {
            throw BotInvalidMoveException( PL2 );
        }
    }
    if( to1 || to2 )
    {
        if( to1 && to2 )
        {
            throw TimeoutException( BOTH );
        }
        else if( to1 )
        {
            throw TimeoutException( PL1 );
        }
        else
        {
            throw TimeoutException( PL2 );
        }
    }
    if( cr1 || cr2 )
    {
        if( cr1 && cr2 )
        {
            throw BotException( BOTH );
        }
        else if( cr1 )
        {
            throw BotException( PL1 );
        }
        else
        {
            throw BotException( PL2 );
        }
    }
}


