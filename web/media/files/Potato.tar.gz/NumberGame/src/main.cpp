/**
* @file main.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-01-27
* NumberGame 
*/

#include <sys/stat.h>
#include <unistd.h>
#include <cstdlib>
#include <cstdio>
#include <string>

#include "NumberGame.h"
#include "LoggedNumberGame.h"
#include "NumberGamePlayer.h"
#include "botLoader.h"

using namespace std;
using namespace Potato;

extern int optind, opterr;

Options g_Options;

static void runGame( string player1Path, string player2Path );

int main( int argc, char* argv[] )
{
    int opt;

    loadInit();

    // Parse command line options 
    while( ( opt = getopt( argc, argv, "strvh" ) ) != -1 )
    {
        switch( opt ) 
        {
            case 't':
                g_Options.ignoreTime = true;
                break;
            case 's':
                g_Options.shouldStep = true;
                break;
            case 'v':
                g_Options.isVerbose = true;
                break;
            case 'h':
            default: /* '?' */
                fprintf( stderr, "Usage: %s [options] <bot-1> <bot-2>\n", argv[ 0 ] );
                fprintf( stderr, "Options:\n" );
                fprintf( stderr, "\t-h \t--\t Print this message\n" );
                fprintf( stderr, "\t-v \t--\t Verbose (print all game states)\n" );
                fprintf( stderr, "\t-s \t--\t Step through a game\n" );
                exit( EXIT_FAILURE );
        }
    }

    if( g_Options.mode == NORMAL && ( argc - optind == 2 ) )
    {
        string player1Path = string( argv[ optind + 0 ] );
        string player2Path = string( argv[ optind + 1 ] );

        runGame( player1Path, player2Path );
    }
    else if( g_Options.mode == TEST )
    {
        // Currently does nothing
        //runTest();
    }
    else
    {
        fprintf( stderr, "Usage: %s [options] <bot-1> <bot-2>\n", argv[ 0 ] );
        fprintf( stderr, "Options:\n" );
        fprintf( stderr, "\t-h \t--\t Print this message\n" );
        fprintf( stderr, "\t-v \t--\t Verbose (print all game states)\n" );
        fprintf( stderr, "\t-s \t--\t Step through a game\n" );
        exit( EXIT_FAILURE );
    }

    return 0;
}

static void runGame( string player1Path, string player2Path )
{
    // Load bots
    NumberGamePlayer* player1_ptr = NULL;
    NumberGamePlayer* player2_ptr = NULL;
    bool dq1 = false, dq2 = false;

    try
    {
        player1_ptr = loadBot( player1Path );
    }
    catch(exception e)
    {
        dq1 = true;
    }

    try
    {
        player2_ptr = loadBot( player2Path );
    }
    catch(exception e)
    {
        dq2 = true;
    }

    if( dq1 || dq2 )
    {
        string dq_str = (dq1 && dq2) ? "DQ3" : ( (dq1) ? "DQ1" : "DQ2" );
        cout << dq_str << endl;
        return;
    }

    NumberGamePlayer& player1 = *player1_ptr;
    NumberGamePlayer& player2 = *player2_ptr;
    LoggedNumberGame game( "game.log", player1, player2 );

    try
    {
        int margin = game.startGame();

        if( margin == 0 )
        {
            cerr << "[Draw]" << endl;
        }
        else
        {
            string playerStr = ( margin > 0 ) ? "Player 1" : "Player 2";
            cerr << "[Win]: " + playerStr << endl;
        }
        
        cout << margin << endl;
    }
    catch( BotInvalidMoveException& e )
    {
        string playerStr;
        switch( e.player )
        {
            case PL1:
                playerStr = "Player 1";
                cout << "DQ1" << endl;
                break;
            case PL2:
                playerStr = "Player 2";
                cout << "DQ2" << endl;
                break;
            case BOTH:
                playerStr = "Both";
                cout << "DQ3" << endl;
                break;
            case NONE:
            default:
                ;
        }
        cerr << "[Invalid Move]: " << playerStr << endl;
    }
    catch( TimeoutException& e )
    {
        string playerStr;
        switch( e.player )
        {
            case PL1:
                playerStr = "Player 1";
                cout << "TO1" << endl;
                break;
            case PL2:
                playerStr = "Player 2";
                cout << "TO2" << endl;
                break;
            case BOTH:
                playerStr = "Both";
                cout << "TO3" << endl;
                break;
            case NONE:
            default:
                ;
        }
        cerr << "[Timeout]: " << playerStr << endl;
    }
    catch( BotException& e )
    {
        string playerStr;
        switch( e.player )
        {
            case PL1:
                playerStr = "Player 1";
                cout << "CR1" << endl;
                break;
            case PL2:
                playerStr = "Player 2";
                cout << "CR2" << endl;
                break;
            case BOTH:
                playerStr = "Both";
                cout << "CR3" << endl;
                break;
            case NONE:
            default:
                ;
        }
        cerr << "[Unhandled Exception]: " << playerStr << endl;
    }
    catch( exception& e )
    {
        cout << "ERR" << endl;
    }
}

