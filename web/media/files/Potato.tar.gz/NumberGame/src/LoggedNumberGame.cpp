/**
 * @file LoggedNumberGame.cpp
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-01
 * Simulates the execution of the game
 */
#include <iostream>
#include <fstream>
using namespace std;

#include "LoggedNumberGame.h"
using namespace Potato;

LoggedNumberGame::LoggedNumberGame( string logfile, NumberGamePlayer& player1, NumberGamePlayer& player2 ) : 
    NumberGame( player1, player2 ), log( logfile.c_str(), fstream::out )
{
}

LoggedNumberGame::~LoggedNumberGame()
{
    log.close();
}

void LoggedNumberGame::postPlayActions( Move& move1, Move& move2 )
{
    log << move1 << " " << move2 << endl;
}

