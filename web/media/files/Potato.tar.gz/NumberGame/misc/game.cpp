#include<stdio.h>
#include<iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

struct Reward {
public:
    int Player1;
    int Player2;
};
class Game {
    int player1Score;
    int player2Score;
    int gameStatus;
    void updateScore(int player1Reward, int player2Reward);
    bool validMove(int move);  
public:
        Game() {
        player1Score = 0;
        player2Score = 0;
        gameStatus = -1;
    }
    void move(int player1move, int player2move, Reward* result);
    void printResult();
    int getStatus();
};
void Game::move(int player1move, int player2move, Reward* result) {
    if(!validMove(player1move)){
        cout<<"Invalid Move Player 1\n";
        exit (1);
    }
    if(!validMove(player2move)){
        cout<<"Invalid Move Player 2\n";
        exit (1);
    }

    if (player1move - player2move == 1) {
        result->Player1 = 0;
        result->Player2 = player1move + player2move;
        updateScore(0, player1move + player2move);
    } else if (player2move - player1move == 1) {
        result->Player1 = player1move + player2move;
        result->Player2 = 0;
        updateScore(player1move + player2move, 0);
    } else {
        result->Player1 = player1move;
        result->Player2 = player2move;
        updateScore(player1move, player2move);
    }
    
}
void Game::updateScore(int player1Reward, int player2Reward) {
    player1Score = player1Score + player1Reward;
    player2Score = player2Score + player2Reward;
    if (player1Score >= 100 && player2Score >= 100) {
        gameStatus = 0;
    } else if (player1Score >= 100) {
        gameStatus = 1;
    } else if (player2Score >= 100) {
        gameStatus = 2;
    }
}
bool Game::validMove(int move){
    if(move>=1 && move<=5){
        return true;
    }
    else {return false;}
}
int Game::getStatus(){
    return gameStatus;
}
void Game::printResult(){
    if(gameStatus==0){
        cout<<"Game Drawn\n";
    } else if (gameStatus==1){
        cout<<"Player 1 won!\n";
    } else if (gameStatus==2){
        cout<<"Player 2 won!\n";
    } else {
        cout<<"Game not yet completed";
    }
}

class Player {
public:
    virtual int getMove(Reward* result) = 0;
};


//Example Random Player Class
class P1 : public Player {
public:
    int getMove(Reward* result) {
        return rand() % 5 + 1;
    }
};

int main() {
    int player1Move;
    int player2Move;
    srand(time(NULL));
    Game game1 = Game();
    Player* x=(Player*) new P1();
    Player* y=(Player*) new P1();
    Reward* result = new Reward();
    result->Player1=0;
    result->Player2=0;
    cout<<"-------------------------------\nPlayer1 Player2 \n";
    do{
        player1Move = x->getMove(result);

        player2Move = y->getMove(result);
        cout<<"  "<<player1Move<<" \t  "<<player2Move<<"\t Rewards: \t";
        game1.move(player1Move, player2Move, result);
        cout << result->Player1 << "\t" << result->Player2 << "\n";

    } while (game1.getStatus() == -1);
    game1.printResult();
    return 0;
}