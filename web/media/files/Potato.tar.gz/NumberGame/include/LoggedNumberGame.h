#ifndef LOGGEDNUMBERGAME_H
#define LOGGEDNUMBERGAME_H

/**
 * @brief LoggedNumberGame Logs to a file
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-01-27
 */

#include "NumberGame.h"
#include <string>
#include <fstream>
using namespace std;

namespace Potato
{
    class LoggedNumberGame: public NumberGame
    {
        public:

            /**
             * Open stream to log file
             */
            LoggedNumberGame( string logfile, NumberGamePlayer& player1, NumberGamePlayer& player2, int duration );
            LoggedNumberGame( string logfile, NumberGamePlayer& player1, NumberGamePlayer& player2 );

            /**
             * Close log file
             */
            ~LoggedNumberGame();
        protected:
            fstream log;

            /**
             * Log moves to log file
             */
            void postPlayActions( Move& move1, Move& move2 );
    };
}

#endif /* #ifndef LOGGEDOTHELLOGAME_H */
