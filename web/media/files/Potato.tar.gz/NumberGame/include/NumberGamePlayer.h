#ifndef NUMBERGAMEPLAYER_H
#define NUMBERGAMEPLAYER_H

/**
 * @brief NumberPlayer Class that defines interface for all bots
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-01
 */
namespace Potato
{
    class NumberGamePlayer;
}

#include "NumberGame.h"

namespace Potato
{
    class NumberGamePlayer
    {
        public:
            /**
             * Default constructor
             */
            NumberGamePlayer();
            
            /**
             * Default destructor
             */
            virtual ~NumberGamePlayer( ) {}

            virtual Move play( const Move oppPrevMove );

        private:

    };

    class BotException : public exception
    {
        public:
            const Player& player;
            BotException( const Player& player ) throw() :
                player( player ) {}
            ~BotException() throw() {}
            const char* what() const throw()
            {
                return "Bot threw an unhandled exception.";
            }
    };
}

#endif /* #ifndef NUMBERGAMEPLAYER_H */
