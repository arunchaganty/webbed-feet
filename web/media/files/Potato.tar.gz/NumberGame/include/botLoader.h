#ifndef BOTLOADER_H
#define BOTLOADER_H

/**
 * @brief BotLoader Loads a bot
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-01-27
 */

#include "NumberGame.h"
#include "NumberGamePlayer.h"

using namespace Potato;

void loadInit();
NumberGamePlayer* loadBot( string botPath );

#endif /* #ifndef BOTLOADER_H */
