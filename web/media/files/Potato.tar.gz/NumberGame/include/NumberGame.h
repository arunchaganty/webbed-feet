#ifndef NUMBER_GAME_H
#define NUMBER_GAME_H

/**
 * @brief Common NumberGame primitives
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-01-27
 */

#include <iostream>
#include <cstring>

#define MIN_CHOICE 1
#define MAX_CHOICE 5
using namespace std;

namespace Potato
{
    enum Mode
    {
        NORMAL=0,
        REPLAY=1,
        TEST=2
    };

    enum Player
    {
        NONE=0,
        PL1=1,
        PL2=2,
        BOTH=3
    };

    struct Options
    {
        Mode mode;
        bool isVerbose;
        bool shouldStep;
        bool ignoreTime;

        Options()
        {
            mode = NORMAL;
            isVerbose = false;
        }

    };

    typedef int Move;
}

#include "NumberGamePlayer.h"

namespace Potato
{
    class NumberGame
    {
        public:
            /**
             * Start a game with two players
             */
            NumberGame( NumberGamePlayer& player1, NumberGamePlayer& player2, int duration );
            NumberGame( NumberGamePlayer& player1, NumberGamePlayer& player2 );

            bool validateMove( const Move move ); 
            void makeMove( const Move move1, const Move move2 ); 

            void printState();
            /**
             * Play a game
             * @return - Player1 score - Player2 score
             */
            int startGame();
            int replayGame( string filename );

            int getPlays();
            int getDuration();

            int getPlayer1Score();
            int getPlayer2Score();

            static const int Min = MIN_CHOICE;
            static const int Max = MAX_CHOICE;

        protected:
            NumberGamePlayer& player1;
            NumberGamePlayer& player2;

            int duration;
            int plays;

            int player1Score;
            int player2Score;

            void printState( Move move1, Move move2 );

            /**
             * Allows inheriters to define actions that should be performed
             * after a move is played.
             */
            virtual void postPlayActions( Move& move1, Move& move2 );

            bool isGameOver( );
    };

    class InvalidMoveException: public exception
    {
        public:
        Move move;

        InvalidMoveException( const Move& move ): move(move) 
        {
            char move_str[] = {'0' + (char)move,'\0'};
            expl = "Invalid Move(" + string(move_str) + ")";
        }

        ~InvalidMoveException() throw() {}

        const char* what() const throw ()
        {
            return expl.c_str();
        }

        private:
            string expl;
    };

    class TimeoutException: public exception
    {
        public:
            const Player player;

            TimeoutException( const Player& player ) throw():
                player( player ) {}
            ~TimeoutException() throw() {}

            const char* what() 
            {
                return "Player timed out";
            }
    };

    class BotInvalidMoveException: public exception
    {
        public:
            const Player& player;

            BotInvalidMoveException( const Player& player ) throw():
                player( player ) {}
            ~BotInvalidMoveException() throw() {}

            const char* what() 
            {
                return "Player timed out";
            }
    };
}

#endif /* #ifndef OTHELLO_H */

